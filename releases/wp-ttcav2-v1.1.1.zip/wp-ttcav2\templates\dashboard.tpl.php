<?php
/**
 * Template du tableau TTCAV pour le shortcode WordPress.
 * Variables disponibles : $players, $club_name, $club_id, $is_admin
 */
$rank = 1;
?>
<div id="ttcav-app" class="dark-theme">

    <div class="container-fluid py-4">

        <header class="text-center mb-4">
            <h2 class="fw-bold">
                Les compétiteurs du <?php echo esc_html( $club_name ); ?>
                <small class="club-number">(<?php echo esc_html( $club_id ); ?>)</small>
            </h2>
            <p class="lead subtitle">Consultez les classements, les progressions et l'historique détaillé de chaque joueur.</p>
        </header>



        <!-- Barre de recherche + contrôles PC -->
        <div class="search-bar-container mb-4">
            <div class="row g-3 align-items-center">
                <div class="col-md">
                    <div class="search-input-wrapper">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" id="ttcav-playerSearch" class="form-control" placeholder="Rechercher un joueur...">
                        <i class="fas fa-times-circle search-clear" id="ttcav-clearSearch" style="display:none;"></i>
                    </div>
                </div>

                <div class="col-md-auto ttcav-pc-controls align-items-center gap-2">
                    <div class="btn-group" role="group" id="ttcav-avatarSizeSelectorPC">
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-size="sm" title="Petites vignettes"><i class="fas fa-th"></i></button>
                        <button type="button" class="btn btn-outline-secondary btn-sm active btn-secondary" data-size="md" title="Moyennes"><i class="fas fa-th-large"></i></button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-size="lg" title="Grandes"><i class="fas fa-square"></i></button>
                    </div>

                    <?php if ( $is_admin ) : ?>
                    <button class="btn btn-outline-warning btn-sm" id="ttcav-btnSyncAllPC">
                        <i class="fas fa-bolt me-1"></i> Sync Club
                    </button>
                    <button class="btn btn-outline-light btn-sm" onclick="location.reload()" title="Rafraîchir">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <?php endif; ?>

                    <button class="theme-toggle" id="ttcav-themeToggleBtn" title="Basculer thème">
                        <i class="fas fa-sun theme-icon-sun"></i>
                        <span class="theme-toggle-thumb"></span>
                        <i class="fas fa-moon theme-icon-moon"></i>
                    </button>
                </div>

                <div class="col-md-auto text-center text-md-start">
                    <div class="stats-summary">
                        <span id="ttcav-playerCount" class="fw-bold"><?php echo count( $players ); ?></span> joueurs
                    </div>
                </div>
            </div>

            <!-- Contrôles Mobile -->
            <div class="ttcav-mobile-controls justify-content-between align-items-center mt-3 flex-wrap gap-2">
                <div class="d-flex align-items-center gap-2">
                    <div class="btn-group" role="group" id="ttcav-avatarSizeSelectorMobile">
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-size="sm"><i class="fas fa-th"></i></button>
                        <button type="button" class="btn btn-outline-secondary btn-sm active btn-secondary" data-size="md"><i class="fas fa-th-large"></i></button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-size="lg"><i class="fas fa-square"></i></button>
                    </div>
                    <div class="sort-selector-wrapper">
                        <select id="ttcav-mobileSortCol" class="form-select-sm">
                            <option value="2">Officiel</option>
                            <option value="3">Phase 1</option>
                            <option value="4">Phase 2</option>
                            <option value="5">Mensuel</option>
                            <option value="6" selected>Virtuel</option>
                            <option value="7">Prog. Mois</option>
                            <option value="8">Prog. Saison</option>
                        </select>
                        <select id="ttcav-mobileSortDir" class="form-select-sm">
                            <option value="desc">DESC</option>
                            <option value="asc">ASC</option>
                        </select>
                    </div>
                </div>

                <div class="d-flex gap-2 align-items-center">
                    <?php if ( $is_admin ) : ?>
                    <button class="btn btn-outline-warning btn-sm" id="ttcav-btnSyncAllMobile">
                        <i class="fas fa-bolt me-1"></i> Sync
                    </button>
                    <button class="btn btn-outline-light btn-sm" onclick="location.reload()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <?php endif; ?>
                    <button class="theme-toggle" id="ttcav-themeToggleBtnMobile" title="Thème">
                        <i class="fas fa-sun theme-icon-sun"></i>
                        <span class="theme-toggle-thumb"></span>
                        <i class="fas fa-moon theme-icon-moon"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Barre de progression sync -->
        <div id="ttcav-syncProgressContainer" class="hidden mb-4 p-3 history-card">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-bold"><i class="fas fa-sync fa-spin me-2"></i> Synchronisation en cours...</span>
                <span id="ttcav-syncProgressText" class="badge bg-warning text-dark">0/0</span>
            </div>
            <div class="progress" style="height:10px; background:rgba(255,255,255,0.1);">
                <div id="ttcav-syncProgressBar" class="progress-bar bg-warning progress-bar-striped progress-bar-animated" role="progressbar" style="width:0%"></div>
            </div>
        </div>

        <!-- Tableau principal -->
        <div class="table-responsive">
            <table class="players-table table table-hover mb-0" id="ttcav-playersTable">
                <thead>
                    <tr>
                        <th class="col-rank pc-only-cell">#</th>
                        <th class="col-player"><i class="fas fa-sort"></i> JOUEUR</th>
                        <th class="col-stat pc-only-cell"><i class="fas fa-sort"></i> OFFICIEL</th>
                        <th class="col-stat"><i class="fas fa-sort"></i> PH. 1</th>
                        <th class="col-stat"><i class="fas fa-sort"></i> PH. 2</th>
                        <th class="col-stat"><i class="fas fa-sort"></i> MENSUEL</th>
                        <th class="col-stat col-virtuel"><i class="fas fa-sort-down"></i> VIRTUEL</th>
                        <th class="col-stat"><i class="fas fa-calendar-day"></i> MOIS</th>
                        <th class="col-stat"><i class="fas fa-sort"></i> ANNÉE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $players ) ) : ?>
                        <tr>
                            <td colspan="9" class="text-center p-5">
                                <div class="p-4" style="background: rgba(255,255,255,0.05); border-radius: 12px; border: 1px dashed rgba(255,255,255,0.1);">
                                    <i class="fas fa-users-slash fa-3x mb-3" style="opacity: 0.3;"></i>
                                    <h4 class="text-light">Aucun joueur dans la base</h4>
                                    <p class="text-muted">La connexion à la base est réussie, mais elle est vide.</p>
                                    <?php if ( $is_admin ) : ?>
                                        <div class="mt-3">
                                            <p class="small text-warning">Cliquez sur le bouton <strong><i class="fas fa-bolt"></i> SYNC CLUB</strong> ci-dessus pour importer les joueurs du club <code><?php echo esc_html($club_id); ?></code>.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php else : ?>
                    <?php foreach ( $players as $p ) :
                        $safeMensuel  = ( $p['points_mensuel']  > 0 ) ? $p['points_mensuel']  : $p['points_officiel'];
                        $pointsPh1    = ( $p['points_initial']  > 0 ) ? $p['points_initial']  : $p['points_officiel'];
                        $pointsPh2    = ( $p['points_ph2']      > 0 ) ? $p['points_ph2']      : $p['points_officiel'];
                        $pointsVirt   = ( $p['points_virtuel']  > 0 ) ? $p['points_virtuel']  : $safeMensuel;
                        $progMois     = ( $p['points_mensuel_precedent'] > 0 ) ? ( $safeMensuel - $p['points_mensuel_precedent'] ) : 0;
                        $progAnnee    = $pointsVirt - $pointsPh1;
                        $progMO       = $safeMensuel - $p['points_officiel'];
                        $progVP2      = $pointsVirt - $pointsPh2;
                        $initials     = strtoupper( substr( $p['nom'], 0, 1 ) . substr( $p['prenom'], 0, 1 ) );
                        $avatarUrl    = ! empty( $p['avatar'] ) ? esc_url( 'https://ttcav2.coolz.fr/assets/avatars/' . $p['avatar'] ) : '';
                    ?>
                    <tr class="player-row" data-licence="<?php echo esc_attr( $p['licence'] ); ?>">
                        <td class="col-rank text-center pc-only-cell">
                            <span class="rank-number"><?php echo $rank++; ?></span>
                        </td>
                        <td class="col-player">
                            <div class="player-info">
                                <div class="mobile-rank-wrapper">
                                    <span class="rank-number"><?php echo $rank - 1; ?></span>
                                </div>
                                <div class="player-avatar avatar-md" data-licence="<?php echo esc_attr( $p['licence'] ); ?>">
                                    <?php if ( $avatarUrl ) : ?>
                                        <div class="avatar-crop-container">
                                            <img src="<?php echo $avatarUrl; ?>"
                                                 alt=""
                                                 class="avatar-img"
                                                 style="width:<?php echo ( $p['avatar_zoom'] ?? 1 ) * 100; ?>%; left:<?php echo $p['avatar_pos_x'] ?? 0; ?>%; top:<?php echo $p['avatar_pos_y'] ?? 0; ?>%;">
                                        </div>
                                    <?php else : ?>
                                        <div class="avatar-initials"><?php echo esc_html( $initials ); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="player-name-wrapper">
                                    <span class="player-nom"><?php echo esc_html( strtoupper( $p['nom'] ) ); ?></span>
                                    <span class="player-prenom"><?php echo esc_html( $p['prenom'] ); ?></span>
                                    <span class="player-licence"><?php echo esc_html( $p['licence'] ); ?></span>
                                </div>
                                <div class="mobile-actions-wrapper">
                                    <button class="btn-mobile-details" onclick="event.stopPropagation(); ttcavToggleDetails('<?php echo esc_js( $p['licence'] ); ?>')">
                                        Détails
                                    </button>
                                </div>
                            </div>
                        </td>
                        <td class="col-stat val-official pc-only-cell" data-label="OFFICIEL"><?php echo number_format( $p['points_officiel'], 1, '.', '' ); ?></td>
                        <td class="col-stat" data-label="PH1"><?php echo number_format( $pointsPh1, 1, '.', '' ); ?></td>
                        <td class="col-stat" data-label="PH2"><?php echo number_format( $pointsPh2, 1, '.', '' ); ?></td>
                        <td class="col-stat val-monthly" data-label="MENSUEL">
                            <div class="d-flex align-items-center justify-content-center gap-1">
                                <span class="main-val"><?php echo number_format( $safeMensuel, 1, '.', '' ); ?></span>
                                <?php if ( $progMO != 0 ) : ?>
                                    <span class="prog-val prog-badge <?php echo $progMO > 0 ? 'plus' : 'minus'; ?>">
                                        <?php echo ( $progMO > 0 ? '+' : '' ) . number_format( $progMO, 1, '.', '' ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="col-stat col-virtuel-big" data-label="VIRTUEL">
                            <div class="d-flex align-items-center justify-content-center gap-1">
                                <span class="main-val"><?php echo number_format( $pointsVirt, 1, '.', '' ); ?></span>
                                <?php if ( $progVP2 != 0 ) : ?>
                                    <span class="prog-val prog-badge <?php echo $progVP2 > 0 ? 'plus' : 'minus'; ?>">
                                        <?php echo ( $progVP2 > 0 ? '+' : '' ) . number_format( $progVP2, 1, '.', '' ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="col-stat prog-highlight stat-center-bold <?php echo $progMois > 0 ? 'plus' : ( $progMois < 0 ? 'minus' : '' ); ?>" data-label="MOIS">
                            <?php echo ( $progMois > 0 ? '+' : '' ) . number_format( $progMois, 1, '.', '' ); ?>
                        </td>
                        <td class="col-stat prog-highlight stat-center-bold <?php echo $progAnnee > 0 ? 'plus' : ( $progAnnee < 0 ? 'minus' : '' ); ?>" data-label="ANNÉE">
                            <?php echo ( $progAnnee > 0 ? '+' : '' ) . number_format( $progAnnee, 1, '.', '' ); ?>
                        </td>
                    </tr>
                    <tr class="details-row hidden-row" id="ttcav-details-<?php echo esc_attr( $p['licence'] ); ?>">
                        <td colspan="9">
                            <div class="details-content">
                                <div class="details-header">
                                    <h3>Historique &amp; Matchs</h3>
                                    <div class="details-actions">
                                        <button class="btn-close-details" onclick="ttcavToggleDetails('<?php echo esc_js( $p['licence'] ); ?>')">
                                            <i class="fas fa-times"></i> Fermer
                                        </button>
                                    </div>
                                </div>
                                <div class="chart-container mb-4">
                                    <canvas id="ttcav-chart-<?php echo esc_attr( $p['licence'] ); ?>"></canvas>
                                </div>
                                <div class="matches-section mt-4">
                                    <h6 class="text-light text-uppercase small fw-bold mb-3" style="opacity:.6;">Derniers matchs</h6>
                                    <div class="matches-container">
                                        <div class="text-center p-3 text-muted">Chargement des matchs...</div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div><!-- .table-responsive -->

    </div><!-- .container-fluid -->
</div><!-- #ttcav-app -->
