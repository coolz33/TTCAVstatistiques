/**
 * TTCAV Dashboard — Plugin WordPress
 * Adapté de dashboard.js : toutes les URLs fetch pointent vers admin-ajax.php
 * Les boutons sync/refresh sont masqués côté PHP si non-admin (ttcav.is_admin = false)
 */

/* ========== THÈME ========== */
(function initTheme() {
    const saved = localStorage.getItem('ttcav_theme') || 'dark';
    applyTheme(saved);
})();

function applyTheme(theme) {
    const app   = document.getElementById('ttcav-app');
    const body  = document.body;
    [ app, body ].forEach(el => {
        if (!el) return;
        el.classList.remove('dark-theme', 'light-theme');
        el.classList.add(theme + '-theme');
    });
    const title = theme === 'light' ? 'Passer en thème sombre' : 'Passer en thème clair';
    document.querySelectorAll('#ttcav-themeToggleBtn, #ttcav-themeToggleBtnMobile').forEach(b => {
        if (b) b.title = title;
    });
}

function toggleTheme() {
    const app   = document.getElementById('ttcav-app');
    const theme = (app && app.classList.contains('dark-theme')) ? 'light' : 'dark';
    applyTheme(theme);
    localStorage.setItem('ttcav_theme', theme);
}

/* ========== INIT DOM ========== */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#ttcav-themeToggleBtn, #ttcav-themeToggleBtnMobile').forEach(btn => {
        if (btn) btn.addEventListener('click', toggleTheme);
    });

    initSearch();
    initAvatarSize();
    initSort();
    initRowClick();

    if (ttcav.is_admin) {
        initSyncAll();
    }
});

/* ========== RECHERCHE ========== */
function initSearch() {
    const input = document.getElementById('ttcav-playerSearch');
    const clear = document.getElementById('ttcav-clearSearch');
    if (!input) return;

    input.addEventListener('input', () => {
        const q     = input.value.trim().toLowerCase();
        const count = filterRows(q);
        const ctr   = document.getElementById('ttcav-playerCount');
        if (ctr) ctr.textContent = count;
        if (clear) clear.style.display = q ? 'block' : 'none';
    });

    if (clear) {
        clear.addEventListener('click', () => {
            input.value = '';
            input.dispatchEvent(new Event('input'));
            input.focus();
        });
    }
}

function filterRows(q) {
    let count = 0;
    document.querySelectorAll('#ttcav-playersTable .player-row').forEach(row => {
        const text = row.textContent.toLowerCase();
        const show = !q || text.includes(q);
        row.style.display = show ? '' : 'none';
        const licence = row.dataset.licence;
        const detRow  = document.getElementById('ttcav-details-' + licence);
        if (detRow) detRow.style.display = 'none';
        if (show) count++;
    });
    return count;
}

/* ========== AVATAR SIZE ========== */
const AVATAR_SIZES = { sm: 28, md: 40, lg: 60 };

function initAvatarSize() {
    ['ttcav-avatarSizeSelectorPC', 'ttcav-avatarSizeSelectorMobile'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('click', e => {
            const btn = e.target.closest('[data-size]');
            if (!btn) return;
            const size = btn.dataset.size;
            document.querySelectorAll('.player-avatar').forEach(av => {
                av.className = av.className.replace(/\bavatar-\w+\b/, '') + ' avatar-' + size;
                const px = AVATAR_SIZES[size] || 40;
                av.style.width = av.style.height = px + 'px';
            });
            document.querySelectorAll('[id$="avatarSizeSelectorPC"] button, [id$="avatarSizeSelectorMobile"] button').forEach(b => {
                b.classList.toggle('active', b.dataset.size === size);
            });
        });
    });
}

/* ========== TRI MOBILE ========== */
function initSort() {
    const col = document.getElementById('ttcav-mobileSortCol');
    const dir = document.getElementById('ttcav-mobileSortDir');
    if (!col || !dir) return;
    const onChange = () => sortTable(parseInt(col.value), dir.value);
    col.addEventListener('change', onChange);
    dir.addEventListener('change', onChange);
}

function sortTable(colIndex, direction) {
    const tbody  = document.querySelector('#ttcav-playersTable tbody');
    if (!tbody) return;
    const rows   = Array.from(tbody.querySelectorAll('tr.player-row'));
    const sorted = rows.sort((a, b) => {
        const av = parseFloat(a.cells[colIndex]?.textContent) || 0;
        const bv = parseFloat(b.cells[colIndex]?.textContent) || 0;
        return direction === 'asc' ? av - bv : bv - av;
    });
    sorted.forEach(row => {
        tbody.appendChild(row);
        const licence = row.dataset.licence;
        const det     = document.getElementById('ttcav-details-' + licence);
        if (det) tbody.appendChild(det);
    });
    sorted.forEach((row, i) => {
        row.querySelectorAll('.rank-number').forEach(el => el.textContent = i + 1);
    });
}

/* ========== CLICK LIGNE → DÉTAILS ========== */
function initRowClick() {
    document.querySelectorAll('#ttcav-playersTable .player-row').forEach(row => {
        row.addEventListener('click', e => {
            if (e.target.closest('.btn-mobile-details, .player-avatar')) return;
            const licence = row.dataset.licence;
            if (licence) ttcavToggleDetails(licence);
        });
    });
}

function ttcavToggleDetails(licence) {
    const detRow = document.getElementById('ttcav-details-' + licence);
    if (!detRow) return;
    const isOpen = !detRow.classList.contains('hidden-row');
    // Fermer tous
    document.querySelectorAll('.details-row').forEach(r => r.classList.add('hidden-row'));
    document.querySelectorAll('.player-row').forEach(r => r.classList.remove('expanded'));

    if (!isOpen) {
        detRow.classList.remove('hidden-row');
        const playerRow = document.querySelector(`.player-row[data-licence="${licence}"]`);
        if (playerRow) playerRow.classList.add('expanded');
        loadPlayerDetails(licence);
    }
}

/* ========== CHARGEMENT DÉTAILS JOUEUR ========== */
const loadedPlayers = new Set();

function loadPlayerDetails(licence) {
    loadMatches(licence);
    if (!loadedPlayers.has(licence)) {
        loadHistory(licence);
        loadedPlayers.add(licence);
    }
}

function buildAjaxUrl(action, params) {
    const url = new URL(ttcav.ajax_url);
    url.searchParams.set('action', action);
    url.searchParams.set('nonce', ttcav.nonce);
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
    return url.toString();
}

function loadMatches(licence) {
    const container = document.querySelector(`#ttcav-details-${licence} .matches-container`);
    if (!container) return;
    container.innerHTML = '<div class="text-center p-3 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>Chargement...</div>';

    fetch(buildAjaxUrl('ttcav_get_matches', { licence }))
        .then(r => r.json())
        .then(data => {
            if (!Array.isArray(data) || data.length === 0) {
                container.innerHTML = '<div class="text-center p-3 text-muted">Aucun match enregistré.</div>';
                return;
            }
            renderMatches(container, data);
        })
        .catch(() => {
            container.innerHTML = '<div class="text-center p-3 text-danger">Erreur de chargement des matchs.</div>';
        });
}

function renderMatches(container, matches) {
    const groups = {};
    matches.forEach(m => {
        const d = m.date_match ? m.date_match.substring(0, 7) : '?';
        if (!groups[d]) groups[d] = [];
        groups[d].push(m);
    });

    const today = new Date();
    const isBefore11 = today.getDate() <= 10;
    const currentMonthStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0');
    
    let hasProvisionalMatch = false;
    if (isBefore11) {
        hasProvisionalMatch = matches.some(m => {
            const day = m.date_match ? parseInt(m.date_match.substring(8, 10)) : 0;
            return m.date_match && m.date_match.startsWith(currentMonthStr) && day >= 1 && day <= 10;
        });
    }

    let html = '';
    if (hasProvisionalMatch) {
        html += `<div class="alert text-center p-2 mb-3" style="font-size: 0.85rem; border-radius: 6px; background: rgba(255, 193, 7, 0.1); border: 1px solid rgba(255, 193, 7, 0.3); color: #ffc107;">
                    <i class="fas fa-info-circle me-1"></i> Le badge <strong>Provisoire</strong> indique que les points sont calculés avec le classement du mois précédent jusqu'au rafraîchissement des points mensuels le 11 du mois.
                 </div>`;
    }

    const validated = matches.filter(m => m.is_validated == 1);
    const live      = matches.filter(m => m.is_validated == 0);

    if (live.length > 0) {
        html += `<div class="validation-separator live"><i class="fas fa-circle-dot me-1"></i> En attente de validation — ${live.length} match(s)</div>`;
        live.forEach(m => { html += buildMatchCard(m); });
    }
    if (validated.length > 0) {
        html += `<div class="validation-separator validated"><i class="fas fa-check-circle me-1"></i> Validés — ${validated.length} match(s)</div>`;
        validated.forEach(m => { html += buildMatchCard(m); });
    }
    container.innerHTML = html;
}

function buildMatchCard(m) {
    const isWin  = m.victoire_defaite === 'V';
    const pts    = parseFloat(m.points_calcules || m.points_resultat || 0);
    const ptsStr = (pts > 0 ? '+' : '') + pts.toFixed(1);
    const coef   = parseFloat(m.coefficient || 1);
    const dateF  = m.date_match ? new Date(m.date_match).toLocaleDateString('fr-FR', { day:'2-digit', month:'short', year:'2-digit' }) : '';
    const advPts = parseFloat(m.adversaire_points || 0);

    const today = new Date();
    const isBefore11 = today.getDate() <= 10;
    const currentMonthStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0');
    const isCurrentMonth = m.date_match && m.date_match.startsWith(currentMonthStr);
    const day = m.date_match ? parseInt(m.date_match.substring(8, 10)) : 0;
    const isProvisional = isBefore11 && isCurrentMonth && day >= 1 && day <= 10;
    
    let provBadge = '';
    if (isProvisional) {
        provBadge = `<span class="badge bg-warning text-dark me-2" title="Points provisoires basés sur le mois précédent. Ajustement le 11." style="font-size:0.65rem; padding: 2px 4px; border-radius: 4px;"><i class="fas fa-exclamation-triangle"></i> Provisoire</span>`;
    }

    let setsHtml = '';
    if (m.score_detail) {
        m.score_detail.split(',').forEach(set => {
            const parts = set.trim().split('-');
            if (parts.length === 2) {
                const win = parseInt(parts[0]) > parseInt(parts[1]);
                setsHtml += `<div class="set-box ${win ? 'win' : 'loss'}"><div class="set-top">${parts[0]}</div><div class="set-bot">${parts[1]}</div></div>`;
            }
        });
    }

    return `<div class="match-card ${isWin ? 'win' : 'loss'}">
        <div class="match-points-badge ${isWin ? 'win' : 'loss'}">${ptsStr}</div>
        <div class="match-info">
            <div class="match-opponent">${provBadge}${escHtml(m.adversaire_nom || '?')}</div>
            <div class="match-meta text-muted small">
                <span class="match-date-group">${dateF}</span>
                ${advPts > 0 ? `<span class="badge-coef ms-1">${advPts} pts</span>` : ''}
                ${coef !== 1 ? `<span class="badge-coef ms-1">×${coef}</span>` : ''}
                <span class="ms-1 text-muted">${escHtml(m.epreuve || '')}</span>
            </div>
        </div>
        ${setsHtml ? `<div class="sets-display d-flex gap-1">${setsHtml}</div>` : ''}
    </div>`;
}

function loadHistory(licence) {
    const canvas = document.getElementById('ttcav-chart-' + licence);
    if (!canvas) return;

    fetch(buildAjaxUrl('ttcav_get_history', { licence }))
        .then(r => r.json())
        .then(data => {
            if (!Array.isArray(data) || data.length === 0) return;
            renderHistoryChart(canvas, data, licence);
        })
        .catch(() => { /* silencieux si API FFTT indispo */ });
}

function renderHistoryChart(canvas, data, licence) {
    const labels = data.map(h => `${h.saison}-P${h.phase}`);
    const values = data.map(h => parseFloat(h.points));
    const isDark = document.getElementById('ttcav-app')?.classList.contains('dark-theme');
    const gridC  = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
    const textC  = isDark ? 'rgba(255,255,255,0.5)'  : 'rgba(0,0,0,0.5)';

    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Points',
                data: values,
                borderColor: '#ecc94b',
                backgroundColor: 'rgba(236,201,75,0.15)',
                borderWidth: 2,
                pointRadius: 3,
                tension: 0.4,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, zoom: { zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' } } },
            scales: {
                x: { grid: { color: gridC }, ticks: { color: textC, maxRotation: 45 } },
                y: { grid: { color: gridC }, ticks: { color: textC } }
            }
        }
    });
}

/* ========== SYNC ADMIN ========== */
function initSyncAll() {
    ['ttcav-btnSyncAllPC', 'ttcav-btnSyncAllMobile'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', startSyncAll);
    });
}

async function startSyncAll() {
    const rows    = Array.from(document.querySelectorAll('#ttcav-playersTable .player-row'));
    const total   = rows.length;
    const progBar = document.getElementById('ttcav-syncProgressBar');
    const progTxt = document.getElementById('ttcav-syncProgressText');
    const progCnt = document.getElementById('ttcav-syncProgressContainer');

    if (progCnt) progCnt.classList.remove('hidden');
    let done = 0;
    const BATCH = 5;

    for (let i = 0; i < rows.length; i += BATCH) {
        const batch = rows.slice(i, i + BATCH);
        await Promise.all(batch.map(row => syncPlayer(row.dataset.licence)));
        done += batch.length;
        const pct = Math.round((done / total) * 100);
        if (progBar) progBar.style.width = pct + '%';
        if (progTxt) progTxt.textContent = `${done}/${total}`;
    }

    if (progCnt) progCnt.classList.add('hidden');
    location.reload();
}

async function syncPlayer(licence) {
    if (!ttcav.is_admin || !licence) return;
    try {
        const resp = await fetch(buildAjaxUrl('ttcav_sync_player', { licence }));
        return await resp.json();
    } catch (e) {
        return { error: e.message };
    }
}

/* ========== UTILITAIRES ========== */
function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Exposer ttcavToggleDetails globalement (appelé depuis onclick dans le template PHP)
window.ttcavToggleDetails = ttcavToggleDetails;
